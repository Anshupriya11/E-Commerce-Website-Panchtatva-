create table signup
(
    uname varchar(200),
    u_id varchar(200),
    sq varchar(500),
    sa varchar(200),
    pswd varchar(500),
    roll varchar(100),
    std varchar(100)

);

create table emp_signup
(
    ename varchar(200),
    cont_no varchar(15),
    E_id varchar(100),
    pswd varchar(100),
    con_pswd varchar(100),
    Gender varchar(50),
    id_proof varchar(500)
);

create table Add_item
(
    icode varchar(200),
    weight varchar(1000),
    mfg_date varchar(200),
    Exp_date varchar(200),
    item_name varchar(200),
    uprice varchar(500),
    dis varchar(500),
    catg varchar(500),
    b_name varchar(200)
);
create table order_details
(
    cust_id varchar(200),
    order_id varchar(200),
    icode varchar(200),
    quantity varchar(500),
    ord_date varchar(100),
    exp_delivery_date varchar(100),
    t_amt varchar(500),
    status varchar(200)
);
create table cus_details
(
    cust_id varchar(200),
    name varchar(200),
    cont_no varchar(200),
    alt_no varchar(200),
    e_mail varchar(200),
    p_code varchar(200),
    shipp_addr varchar(300),
    bill_addr  varchar(300)
);
create table wish_list
(
    i_id varchar(200),
    cust_id varchar(200),
    quantity varchar(500)  
);
create table item_entry
(
    sn int(),
    icode varchar(50),
    iname varchar(45),
    icat varchar(45),
    brand varchar(45),
    weight varchar(1000),
    mfg_date varchar(45),
    exp_date varchar(45),
    itm desc
)