#! C:\Users\sudhanshu\AppData\Local\Programs\Python\Python311\python.exe
print('contact-type:text/html\r\n\r\n')
import cgi
import mysql.connector
con=mysql.connector.connect(host="localhost",user="pl",passwd="rays@1324",database="panchtatva")
t=con.cursor()
f=cgi.FieldStorage()
try:
    d=f.getvalue('t')
    if d=='ent':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        d4=f.getvalue('t4')
        d5=f.getvalue('t5')
        d6=f.getvalue('t6')
        d7=f.getvalue('t7')
        t.execute('select * from emp_signup order by sn desc limit 1')
        r=t.fetchall()
        if r==[]:
            sts=1
            rol=0
            d8='E001'
        else:
            sts=0
            rol=None
            id=int(r[0][1][1:4])+1
            if id>0 and id<10:
                d8='E00'+str(id)
            elif id>=10 and id<100:
                d8='E0'+str(id)
            else:
                d8='E'+str(id)
        url='insert into emp_signup(emp_id,ename,cont_no,e_id,pswd,date_of_join,gender,id_proof,status,roll) value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        t.execute(url,(d8,d1,d2,d3,d4,d5,d6,d7,sts,rol))
        con.commit()
        print('sign up successfully')
    elif d=='log':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        t.execute('select status,roll from emp_signup where cont_no="'+d1+'" and pswd="'+d2+'"')
        r=t.fetchall()
        if r==[]:
            print(0)
        else:
            if int(r[0][0])==0:
                print(1)
            else:
                print(2)
    elif d=='dash':
        t.execute('select sn from order_details order by sn desc limit 1')
        r1=t.fetchall()
        t.execute('select sn from cus_details order by sn desc limit 1')
        r2=t.fetchall()
        t.execute('select sn from emp_signup order by sn desc limit 1')
        r3=t.fetchall()
        print(r1[0][0],r2[0][0],r3[0][0],sep=',,,')  
    elif d=='home':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        if d2==None:
            t.execute('select * from item_entry order by rand() limit 40')
            r=t.fetchall()
        else:
            t.execute("select * from item_entry where icat='"+d2+"'")
            r=t.fetchall()
        if d1!=None:
            wish=set()
            t.execute('select i_id from wish_list where cust_id="'+str(d1)+'"') 
            r1=t.fetchall()
            for i in r1:
                wish.add(i[0])
        for i in r:
            a=int(i[9])
            a=int(a-a*int(i[10])/100)
            img=''
            if i[12]!=None:
                img=i[12].decode()
            if d1!=None:
                if i[1] not in wish:
                    print('<a href="ProductPage.html"><div class="d5"><div id="div"><div id="aa"><i class="fa fa-heart"></i></div><img src="'+img+'" alt=""><br></div><p id="p0" hidden>'+str(i[1])+'</p><p id="p00" hidden>'+str(i[8])+'</p><p id="p1">'+str(i[2])+'</p><p class="p"> <label><i class="fa fa-rupee"></i>'+str(a)+' <strike> '+str(i[9])+' </strike></label><label>'+str(i[10])+'</label>%  OFF</p><button type="button">'+str(i[5])+'</button><button type="button" class="b1">Add Item</button></div></a>')
                else:
                    print('<a href="ProductPage.html"><div class="d5"><div id="div"><div id="aa"><i class="fa fa-heart" style="color:red"></i></div><img src="'+img+'" alt=""><br></div><p id="p0" hidden>'+str(i[1])+'</p><p id="p00" hidden>'+str(i[8])+'</p><p id="p1">'+str(i[2])+'</p><p class="p"> <label><i class="fa fa-rupee"></i>'+str(a)+' <strike> '+str(i[9])+' </strike></label><label>'+str(i[10])+'</label>%  OFF</p><button type="button">'+str(i[5])+'</button><button type="button" class="b1">Add Item</button></div></a>')
            else:
                print('<a href="ProductPage.html"><div class="d5"><div id="div"><div id="aa"><i class="fa fa-heart"></i></div><img src="'+img+'" alt=""><br></div><p id="p0" hidden>'+str(i[1])+'</p><p id="p00" hidden>'+str(i[8])+'</p><p id="p1">'+str(i[2])+'</p><p class="p"> <label><i class="fa fa-rupee"></i>'+str(a)+' <strike> '+str(i[9])+' </strike></label><label>'+str(i[10])+'</label>%  OFF</p><button type="button">'+str(i[5])+'</button><button type="button" class="b1">Add Item</button></div><a/>')

    elif d=='wish_list':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        if d3!='rgb(113, 113, 113)':
            t.execute('delete from wish_list where i_id="'+d2+'" and cust_id="'+d1+'"')
        else:
            url='insert into wish_list(i_id,cust_id) values(%s,%s)'
            t.execute(url,(d2,d1))
        con.commit()
    elif d=='wish_list1':
        d1=f.getvalue('t1')
        url=('select * from item_entry where icode in (select i_id from wish_list where cust_id="'+d1+'")')
        t.execute(url)
        rs=t.fetchall()
        if(rs!=[]):
            for i in rs:
                if(i[12]!=None):
                    xyx=i[12].decode()
                else:
                    xyx=''
                print('<a href="ProductPage.html"><div id="w_3"><div id="w_a"><img src="'+xyx+'" alt="img"></div><div id="w_b"><br><br><p id="p2">'+i[2]+'</p><p id="p1"><p id="p1"> <i class="fa fa-rupee"></i>'+i[9]+'<strike>&nbsp;&nbsp;750</strike>&nbsp;&nbsp;'+i[10]+' Off</p></div><div><br><br><label><i class="fa fa-cart-plus" id="icon1"></i></label><br><label><i class="fa fa-trash" id="icon"></i><span hidden>'+i[1]+'</span></label></div></div></a>')
        else:
            print('<img src="wish.png" height="50%" width="50%">')
        
            
    elif d=='wishdel':
        b1=f.getvalue('b1')  
        b2=f.getvalue('b2') 
        url=('delete from wish_list where i_id="'+b1+'" and cust_id="'+b2+'"')
        # print(url) 
        t.execute(url)
        con.commit()
        
    elif d=='add_to_card':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        if d3!='green':
            t.execute('delete from add_to_card where itm_id="'+d2+'" and cus_id="'+d1+'"')
        else:
            url='insert into add_to_card(i_id,cust_id,qty) values(%s,%s,%s)'
            t.execute(url,(d1,d2,d3))
        con.commit()
    elif d=='add_to_card1':
        # print('dfgh')
        count=0
        sum=0
        d1=f.getvalue('t1')
        url=("select item_entry.icode,item_entry.iname,item_entry.weight,item_entry.uprice,item_entry.discount,item_entry.pic,add_to_card.qty from item_entry right join add_to_card on item_entry.icode=add_to_card.itm_id where add_to_card.cus_id='"+d1+"'")
        t.execute(url)
        rs=t.fetchall()
        # print(rs)
        if(rs!=[]):
            for i in rs:
                up=float(i[3])-float(i[3])*int(i[4])/100
                count=count+1
                sum=sum+up*int(i[6])
                if(i[5]!=None):
                    abc=i[5].decode()
                else:
                    abc=''
                print('<a href="ProductPage.html"><div class="item"><a href="#" class="btn-remove"> <i class="fa fa-trash" id="icon"></i></a><span hidden>'+i[0]+'</span><div class="preview" style="height: 17rem;"><img src="'+abc+'" alt="" style="height: 100%;"></div><div class="details"><h3>'+i[1]+'</h3><p>'+i[2]+'</p></div><div class="btnss"><div class=" picker"><label class="btn pls"><i class="fa fa-plus"></i></label><p><div class="qntty"><p><input type="text" readonly class="qnt" value="'+i[6]+'" inputmode="numeric"style="width: 4rem; text-align: center; "> @ &#8377; <label>'+str(up)+'</label></p></div><label class="btn minus"><i class="fa fa-minus"></i></label></p></div></div></div></a>')
            print(' <div class="Cart-items" style="width: 100%;" ><div class="checkout"><div class="total"><div><div class="Subtotal">Sub-Total</div><div class="items1">'+str(count)+' items</div></div><div class="total-amount">Rs.<label id="lll">'+str(round(sum,3))+'</label></div></div><button class="button">Place Order</button></div></div>')
        else:
            print('no record found')
             
    elif d=='add_cart':   
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        url1='select qty from add_to_card where cus_id=%s and itm_id=%s'
        t.execute(url1,(d1,d2))
        r=t.fetchall()
        if r==[]:
            url='insert into add_to_card (cus_id,itm_id,qty) values(%s,%s,1)'
            t.execute(url,(d1,d2))
        else:
            url='update add_to_card set qty=%s where cus_id=%s and itm_id=%s'
            t.execute(url,(str(int(r[0][0])+1),d1,d2))
        con.commit()
        print('su')
    elif d=='cart_del':   
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        url='delete from add_to_card where cus_id=%s and itm_id=%s'
        t.execute(url,(d1,d2))
        con.commit()
        print('su')
    elif d=='p_d':
        d1=f.getvalue('t1')
        t.execute('select name,email from cus_signup where mob_no="'+d1+'"')
        r=t.fetchall()
        print(r[0][0],r[0][1],sep=',,')
    elif d=='save':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        url="update cus_signup set name=%s,email=%s where mob_no=%s"
        t.execute(url,(d1,d2,d3))
        con.commit()
    elif d=='cartplus':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        url='update add_to_card set qty=%s where cus_id=%s and itm_id=%s'
        t.execute(url,(d3,d1,d2))
        con.commit()
    elif d=='disc':
        d1=f.getvalue('t1')
        t.execute("select * from item_entry where icode='"+d1+"'")
        r=t.fetchall()
        print(r)
    elif d=='wish_cart':
        d1=f.getvalue('b1')
        d2=f.getvalue('b2')
        url='insert into add_to_card (cus_id,itm_id,qty) values(%s,%s,1)'
        t.execute(url,(d2,d1))
        url1='delete from wish_list where i_id=%s and cust_id=%s'
        t.execute(url1,(d1,d2))
        con.commit()
except Exception as e:
    print('unsccusses',e)
    
    
    