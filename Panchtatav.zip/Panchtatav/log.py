#! C:\Users\sudhanshu\AppData\Local\Programs\Python\Python311\python.exe
print('content-Type:text/html\r\n\r\n')
import cgi
import mysql.connector
con=mysql.connector.connect(host="localhost",user="pl",passwd="rays@1324",database="panchtatva")
t=con.cursor()
f=cgi.FieldStorage()
try:
    d=f.getvalue('t')
    if d=='ent':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        d4=f.getvalue('t4')
        t.execute('select mob_no from cus_signup where mob_no="'+d1+'"')
        r=t.fetchall()
        if r==[]:
            url='insert into cus_signup (mob_no,name,email,paswd) value(%s,%s,%s,%s)'
            t.execute(url,(d1,d2,d3,d4))
            con.commit()
            print('SIGN UP SUCCESSFULLY , NOW YOU CAN LOGIN  !')
        else:
            print(0)
    elif d=='log':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        t.execute('select name from cus_signup where mob_no="'+d1+'" and paswd="'+d2+'"')
        r=t.fetchall()
        if r==[]:
            print(0)
        else:
            nam=r[0][0].split(' ')[0]
            print(d1,nam,sep=',,')
    # d=f.getvalue('a')
    elif d=='cont_ent':
        d1=f.getvalue('a1')
        d2=f.getvalue('a2')
        d3=f.getvalue('a3')
        d4=f.getvalue('a4')
        d5=f.getvalue('a5')
        url=('insert into cont_us (name,subject,cont_no,email,msg) values (%s,%s,%s,%s,%s)')
        t.execute(url,(d1,d2,d3,d4,d5))
        con.commit()
        print('Record inserted succssfully!')
    elif d=='search':
        t.execute('select * from cont_us order by sn desc')
        r=t.fetchall()
        print('<table><thead><tr id="th"><th id="th1">Name</th><th id="th1">Subject</th><th id="th1">Mobile &nbsp; No.</th><th id="th1">Email Id</th><th id="th2">Message</th></tr></thead><tbody>')
        for i in r:
            print(' <tr><td data-label="Name">'+i[1]+'</td><td data-label="Subject">'+i[2]+'</td><td data-label="Mobile No.">'+i[3]+'</td><td data-label="Email Id">'+i[4]+'</td><td data-label="Message">'+i[5]+'</td><td id="td"></td></tr>')
        print('</tbody></table>')
        # print(r)
except Exception as e:
    print('unsuccess',e)