#! C:\Users\sudhanshu\AppData\Local\Programs\Python\Python311\python.exe
print('content-type:text/html\r\n\r\n')
import cgi
import mysql.connector
con=mysql.connector.connect(host="localhost",user="pl",passwd="rays@1324",database="panchtatva")
t=con.cursor()
f=cgi.FieldStorage()
try:
    d=f.getvalue('t')
    if d=='ent':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        d4=f.getvalue('t4')
        d5=f.getvalue('t5')
        d6=f.getvalue('t6')
        d7=f.getvalue('t7')
        d8=f.getvalue('t8')
        d9=f.getvalue('t9')
        d10=f.getvalue('t10')
        d11=f.getvalue('t11')
        d12=f.getvalue('t12')
        url='insert into item_entry (icode,iname,icat,brand,weight, mfg_date,exp_date,itm_desc,uprice,discount,avl_qty,pic)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'

        t.execute(url,(d1,d2,d3,d4,d5,d6,d8,d7,d9,d10,d11,d12))
        con.commit()
        print('entry succes')
    elif d=='search':
        d1=f.getvalue('s1')
        d2=f.getvalue('s2')
        d3=f.getvalue('s3') 
        url='select * from item_entry where'
        if(d1!=None):
            url=url+" icode='"+d1+"'"
        if(d2!=None and d1==None):
            url=url+" icat='"+d2+"'"
        if(d2!=None and d1!=None):
            url=url+" and icat='"+d2+"'"
        if(d3!=None and (d2==None and d1==None)):
            url=url+" brand='"+d3+"'"
        if(d3!=None and (d2!=None or d1!=None)):
            url=url+" and brand='"+d3+"'"
        t.execute(url)
        r=t.fetchall()
        if r==[]:
            print(0)
        else:
            c=1
            print( '  <div>  <button id="e1" type="button"><i class="fa fa-trash"></i> DELETE </button> <br><button id="f" type="button" onclick="clear()">UPDATE <i class="fa fa-pen-to-square"></i></button><table id="table5"><thead> <tr><th id="th0" hidden>SN</th><th id="th1">Item code</th><th id="th1">Item Name</th><th id="th1">Category</th><th id="th1">Brand</th><th id="th1">Weight</th><th id="th1">Mfg Date</th><th id="th2">Expiry Date</th><th id="th1">Item Description</th><th id="th1">Unit price</th><th id="th1">Discount</th><th id="th1">Available Qty</th><th id="th1">Pic</th><th id="th1">CHANGE PIC</th><th id="th3">check box</th></tr></thead><tbody>')
            for a in r:
                d='im'+str(c)
                b=''
                if a[12]!=None:
                    b=a[12].decode()
                print('<tr><td hidden data-label="SN">'+str(a[0])+'   '+'</td><td data-label="ITEM CODE">'+str(a[1])+'   '+'</td><td id="e" contenteditable="true" data-label="ITEM NAME">'+str(a[2])+'   '+'</td><td data-label="CATEGORY"><select id="box1"><option>'+str(a[3])+'</option><option >Fruits & vegetables</option><option>Snacks</option><option>BEVERAGES</option><option>FOODGRAINS</option><option>OIL & MASALA</option><option>Staples</option></select >'+'   '+'</td><td data-label="BRAND" id="e" contenteditable="true">'+str(a[4])+'   '+'</td><td data-label="wEIGHT" id="e" contenteditable="true">'+str(a[5])+'   '+'</td><td data-label="Mfg Date"><input type="date" id="da1" value="'+str(a[6])+'">'+'   '+'</td><td data-label="Expiry Date"><input type="date" id="da2" value="'+str(a[7])+'">'+'   '+'</td><td id="e" contenteditable="true" data-label="ITEM DESCRIPTION">'+str(a[8])+'   '+'</td><td id="e" contenteditable="true" data-label="UNIT PRICE">'+str(a[9])+'   '+'</td><td id="e" contenteditable="true" data-label="DISCOUNT">'+str(a[10])+'   '+'</td><td data-label="AVAILABLE QTY"  id="e" contenteditable="true">'+str(a[11])+'   '+'</td><td data-label="pic"><img src="'+b+'" alt="not available" class="'+d+'" id="img5">'+'   '+'</td><td data-label="CHANGE IMAGE"><input type="file" accept="image/*" id="img6"></td><td data-label="CHECK BOX" id="th12"><input type="radio" name="b" id="ch1"></td> <td id="td"></td> </tr>')
                c=c+1
            print('</tbody></table></div>')
        
    elif d=='delete':
        b=f.getvalue('s1')
        t.execute("delete from item_entry where sn='"+b+"'")
        con.commit()
        print("successfully delete!")
    elif d=='update':
        d1=f.getvalue('s1')
        d2=f.getvalue('s2')
        d3=f.getvalue('s3')
        d4=f.getvalue('s4')
        d5=f.getvalue('s5')
        d6=f.getvalue('s6')
        d7=f.getvalue('s7')
        d8=f.getvalue('s8')
        d9=f.getvalue('s9')
        d10=f.getvalue('s10')
        d11=f.getvalue('s11')
        d12=f.getvalue('s12')
        d13=f.getvalue('s13')
        url=("update item_entry set icode='"+str(d2)+"',iname='"+str(d3)+"',icat='"+str(d4)+"',brand='"+str(d5)+"',weight='"+str(d6)+"',mfg_date='"+str(d7)+"',exp_date='"+str(d8)+"',itm_desc='"+str(d9)+"',uprice='"+str(d10)+"',discount='"+str(d11)+"',avl_qty='"+str(d12)+"',pic='"+str(d13)+"' where sn='"+str(d1)+"'")
        t.execute(url)
        con.commit()
        print('Successfully Update!')
    elif d=='load':
        a=set()
        b=set()
        c=set()
        t.execute('select iname,icode,icat,brand from item_entry')
        r=t.fetchall()
        # print(r)
        for i in r:
            a.add(str(i[0])+'-'+str(i[1]))
            b.add(i[2])
            c.add(i[3])
        for i in a:
            print('<option>'+str(i)+'</option>')
        print(',,,')
        for i in b:
            print('<option>'+str(i)+'</option>')
        print(',,,')
        for i in c:
            print('<option>'+str(i)+'</option>')
except Exception as e:
    print('unsucesses',e) 