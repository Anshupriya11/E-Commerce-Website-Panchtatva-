#! C:\Users\sudhanshu\AppData\Local\Programs\Python\Python311\python.exe
print('contact-type:text/html\r\n\r\n')
import cgi
import mysql.connector
con=mysql.connector.connect(host="localhost",user="pl",passwd="rays@1324",database="panchtatva")
t=con.cursor()
f=cgi.FieldStorage()
try:
    d=f.getvalue('t')
    if d=='ent':
        d1=f.getvalue('t1')
        d2=f.getvalue('t2')
        d3=f.getvalue('t3')
        d4=f.getvalue('t4')
        # d5=f.getvalue('t5')
        d6=f.getvalue('t6')
        d7=f.getvalue('t7')
        d8=f.getvalue('t8')
        url='insert into cus_details(cust_id, name, cont_no, alt_no, p_code, shipp_addr, bill_addr)value(%s,%s,%s,%s,%s,%s,%s)'
        t.execute(url,(d1,d2,d3,d4,d6,d7,d8))
        con.commit()
        print('sign up successfully')
    elif d=='emp':
        t.execute('select * from emp_signup where status=1')
        r=t.fetchall()
        print('<table><thead><tr id="th"><th id="th1">Emp Id</th><th id="th1">Name</th><th id="th1">contact No.</th><th id="th1">Email &nbsp;Id</th><th id="th1">Date Of joining</th><th id="th1">Gender</th><th id="th2">id proof</th><th id="th1">status</th><th id="th1">Roll</th></tr></thead><tbody>')
        for i in r:
            if i[8]!=None:
                a=i[8].decode()
            else:
                a=''
            print(' <tr><td data-label="Emp Id">'+str(i[1])+'</td><td data-label="Name">'+str(i[2])+'</td><td data-label="contact No.">'+str(i[3])+'</td><td data-label="Email Id">'+str(i[4])+'</td><td data-label="Date Of joining">'+str(i[6])+'</td><td data-label="Gender">'+str(i[7])+'</td><td data-label="id proof"><img src="'+str(a )+'" alt="not available" class="'+d+'" id="img5">'+'   '+'</td><td data-label="Status">'+str(i[9])+'</td><td data-label="ROLL">'+str(i[10])+'</td><td id="td"></td></tr>')
        print('</tbody></table>')
    elif d=='search':
        t.execute('select * from cus_details order by sn desc')
        r=t.fetchall()
        print('<table><thead><tr id="th"><th id="th1">Cust Id</th><th id="th1">Name</th><th id="th1">Mobile &nbsp; No.</th><th id="th1">Alternate &nbsp; No.</th><th id="th1">Email Id</th><th id="th1">Pin Code</th><th id="th2">Shipping Address</th><th id="th2">Billing Address</th></tr></thead><tbody>')
        for i in r:
            print(' <tr><td data-label="Cust Id">'+str(i[1])+'</td><td data-label="Name">'+str(i[2])+'</td><td data-label="Mobile No.">'+str(i[3])+'</td><td data-label="Alternate No.">'+str(i[4])+'</td><td data-label="Email Id">'+str(i[5])+'</td><td data-label="Pin Code">'+str(i[6])+'</td><td data-label="Shipping Address">'+str(i[7])+'</td><td data-label="Billing Address">'+str(i[8])+'</td><td id="td"></td></tr>')
        print('</tbody></table>')
except Exception as e:
    print('unsuccess',e)
